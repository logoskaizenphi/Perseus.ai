let http = require('http');

let starWarsAPI = `www.swapi.co`;

var AWS = require('aws-sdk');

var dynamodb = new AWS.DynamoDB({apiVersion: '2012-08-10'});

var Foo = require('./foo');


exports.handler = function(event, context, callback) {

  var foo = new Foo();
  foo.methodA();

//tring to import class for data processing functions
//import DiaglogflowWebhookParser from '/dataLayer/DiaglogflowWebhookParser.js';
//var eventhandler = new DiaglogflowWebhookParser(event);
//console.log(eventhandler.event);

  //Paramters dynamic to each dialogflow intent defined in webhook request
  //let firstName = event.queryResult.parameters['given-name'];
  //let lastName = event.queryResult.parameters['last-name'];

  let responseId = event['responseId'];

  let requestData = JSON.stringify(event);

  let cbdata = {

  "fulfillmentMessages": [

    {

      "platform": "FACEBOOK",

      "card": {

        "title": "Title: this is a title",

        "subtitle": "This is an subtitle.  Text can include unicode characters including emoji 📱.",

        "imageUri": "https://developers.google.com/actions/images/badges/XPM_BADGING_GoogleAssistant_VER.png",

        "buttons": [

          {

            "text": "This is a button",

            "postback": "https://assistant.google.com/"

          }

        ]

      }

    }

  ]

}




 //console.log('Name '+ firstName +' ' + lastName+'    sessionid:'+responseId);





// console.log(JSON.stringify(event, null, '  '));

    var tableName = "DialogflowWebhookData";    

    dynamodb.putItem({

        "TableName": tableName,

        "Item" : {

            // "firstname": {S: firstName},

            "responseId": {S: responseId},
            "responseData": {S: JSON.stringify(cbdata)},
            "requestData" : {S: requestData},
            "date" : {S: Date.now().toString()}



            //"lastname": {S: lastName} 

        }

    }, function(err, data) {

        if (err) {

            console.log('Error putting item into dynamodb failed: '+err);

            context.done('error');

        }

        else {

            console.log('great success: '+JSON.stringify(data, null, '  '));

             









 //callback request for dialogFlow V2 Api

              callback(null, cbdata);





              context.done('success perseus2!');

            };

   });

}